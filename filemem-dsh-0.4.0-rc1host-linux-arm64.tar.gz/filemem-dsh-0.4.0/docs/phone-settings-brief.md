# filemem-dsh 手机侧设置 · 手机端执行 brief（自包含）

> 给：手机侧的 DSH agent。目标：在本机（dsh-Go 手机宿主）把 filemem-dsh
> 的旋钮调成 owner 设定值，且不依赖浏览器设置卡（该卡的表单组件自 DSH
> rc.5 代际才内置；本机 rc.1 代际只渲染只读提示）。你不需要外部上下文——
> 本 brief 自包含。owner 已拍板要做，owner 的设定值在 §3。

## 0. 前提

- 本机已装 `@stennyc/filemem-dsh`（rc1host 构建，`install.sh <version> rc1host`
  或 tarball 手动放置；安装层行的 `id: filemem-dsh`、`name:
  '@stennyc/filemem-dsh'`，行的 `config:` = 发行默认值）。
- filemem 的数据面（Go daemon，14 个工具面：记/召/改/删/supersede/
  计划/排期/共享池）与服务端逻辑**不需要任何配置改动**——本 brief 只调
  旋钮，不动数据面。
- 手机宿主没有 `curl`/`wget`（proot userland）；取文件用 node one-liner
  （seed README「On a phone」节的既有范式）。

## 1. 先查本机状态（你独有信息，桌面侧看不到）

1. `ls /root/.dsh/profiles/` → 本机 App 引擎跑在哪个 profile（通常是
   `web`；以你查到的为准）。**记下 profile 目录**（下称 `<profile>/`）。
2. 读 `<profile>/cordis.patch.yml`（若存在）→ 里面**有没有** `id:
   filemem-dsh` 的行？有则本块追加/合并（config 整体替换，见 §2 规则）；
   无则直接追加。
3. `plugin_manager list_plugins`（或 App 的 Plugins 页）→ `filemem-dsh`
   行 enabled=true、name 读 `@stennyc/filemem-dsh`。若行**未激活**：先
   看 §5 的 all-or-nothing 闸（宿主 composition 缺 `dsh-llm` 服务时整个
   插件不激活——这是 profile composition 缺口，不是本 brief 能修的；
   回报 owner，别硬写块）。
4. 查 `ctx.llm` 是否可解析（行为面）：调一次 `filemem_handoff_extract`
   （任一会话）——响应里**没有** `model_directive` = LLM 面活（宿主
   路由到 provider）；**有** `model_directive` = 确定性地板 + route d
   兜底（App 自带模型可代写摘要回灌，`filemem_llm_result`
   `op: "handoff_summary"`）。两种都正常，只是 §3 的 LLM 预算旋钮的
   生效程度不同。

## 2. 写块到 profile 覆盖层（用户层，宿主升级不覆盖）

把 §3 的块**追加**到 `<profile>/cordis.patch.yml`。三条规则（dsh-base
patch 方言）：

- **整体替换不合并**：块里 `- id: filemem-dsh` 行的 `config:` 会**整体
  替换**安装层那行的 config——所以 §3 块已把安装层需要的每个键
  （含 `daemonPath`/`storePath` 两个路径对）**全量重列**；你增删键时
  也要保持全量（漏键 = 该键丢失，不是回默认）。
- 只写 `<profile>/cordis.patch.yml`。**不写** `/etc/dsh-app/...`（宿主
  升级会被覆盖），**不改**安装层/tarball 的 `cordis.patch.yml`（重装
  会丢）。
- 块里 `- id: filemem-dsh` + `name: '@stennyc/filemem-dsh'`：`name` 是
  **断言**（核对安装层现名）不是改名——对得上才生效，对不上宿主
  warn+skip（§4 验证会暴露）。

## 3. 块本体（owner 设定值 = 发行默认 + 手机注；owner 可逐行调）

```yaml
# filemem-dsh: phone-side tuning（P5 形态；owner 设定值 2026-11-28）。
- id: filemem-dsh
  name: '@stennyc/filemem-dsh'
  config:
    # 路径对：从安装层行原样重列（shell 解析 ~ / 相对；漏了 = 行值丢失）：
    daemonPath: ../dist/filemem-go
    storePath: ~/.dsh/filemem
    # ── 确定性数据面（手机全活）──
    k: 3                       # 自动注入召回上限（0 = 不限）
    enablePreStep: true        # 步骤前水线注入 + 整合
    enableRecall: true         # 步骤尾召回块总开关
    workspaceRefMax: 3         # 跨 workspace 参考道上限（0 = 只出指针行）
    retrieveFilterDefault: false
    waterLevelThreshold: 3     # 积压提前整合阈值
    supersedeMinOverlap: 0.5   # 超写粗筛 Jaccard 下限（0 = 回 Go 的 0.5 地板）
    supersedeMaxConfirms: 5
    # ── LLM 升级面预算（ctx.llm 可解析时真调；不可解析时各腿走
    #    确定性地板 + route d，零崩溃；§1.4 已探明本机处在哪态）──
    consolidationIntervalMin: 30   # owner 可调：手机省电可放宽到 60
    consolidationMaxPerTick: 10
    probeBudgetPerSession: 3
    mergeBudgetPerTick: 4
    contradictionBudgetPerTick: 4
    # ── 中央共享池（需 owner 的 PostgreSQL；本机没有 = 各腿 fail-soft
    #    空响应，正常地板；键重列是为了将来接中央池时不静默回默认）──
    smConfirmedOnlyDefault: true
    smTopKDefault: 50
    smAgentIdDefault: ""
```

## 4. 生效 + 验证

1. **生效**：杀掉引擎进程（`ps` 找 `dsh web` / `bin.js web` 那个）——App
   监督器自动拉起（或直接关开 App）。profile 层 patch 引擎重启即读。
2. 验证（全在 App agent 或 terminal 页）：
   - `plugin_manager list_plugins`：`filemem-dsh` 行 config 显示 §3 的键
     与值（断言 name 失败会 warn——键读不到就查 §2 的 name 拼写）；
   - 行为腿：有存量记忆的会话 pre-step 注入仍出；`filemem_retrieve`
     有答；`filemem_write` 落地；store 根下 `consolidation_log.jsonl`
     按新间隔出 tick；
   - 地板腿（预期形态，非报错）：无中央 PG 时 `filemem_sm_search` 回
     空结果串；`ctx.llm` 不可解析时 L1 handoff 回确定性地板 +
     `model_directive`（route d 可用）。

## 5. 可逆 + 前置闸（all-or-nothing）

- **可逆**：删掉本块 + 杀引擎 = 回安装层行的发行默认值；数据面 14 面
  始终在跑（与块无关）。
- **前置闸**：0.1.1+ 的 rc1host 件声明**完整 inject face**（含 `llm`）——
  宿主静态 inject 列表是激活闸：本机 rc.1 profile **解析不出 `llm`**
  时整个插件不激活（比 0.1.0 的 tools-only 地板件更糟）。此时**先别
  写块**：回报 owner 两选一——(a) 补 profile composition 的 `dsh-llm`
  行（rc.1 代际本身带 `dsh-llm` + `dsh-token-meter` 标准服务，缺的
  是 composition，不是代际——2026-11-27 supercompress 会话已实证）；
  (b) 临时回退 0.1.0 rc1host 件（tools-only inject，releases 分支还在）。
