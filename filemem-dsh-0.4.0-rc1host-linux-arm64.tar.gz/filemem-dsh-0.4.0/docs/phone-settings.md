# filemem-dsh phone-side settings (the P5-pattern owner block)

> 手机侧设置面板的 owner 面方法 —— 形态对齐 supercompress 的 P5 手机配置
> （`P5_PHONE_CONFIG.md` + `P5_PHONE_AGENT_BRIEF.md`）：profile 覆盖层配置块
> + 给手机侧 agent 的自包含 brief（见 `phone-settings-brief.md`，自 0.3.2
> 起随包发行于 `docs/`）。

## What this is

The block that tunes filemem-dsh on the phone host (dsh-Go, the 0.2.2-rc.1
generation) WITHOUT depending on the browser settings card. The card's form
primitives (`@deepseek-ai/dsh-client-ui-primitives`) ship from the rc.5
generation; on the rc.1 phone host the panel renders the read-only
"primitives unavailable" note. Every panel knob is the SAME field as the
row's `config:` — so the phone-side path is: restate the `config` on the
plugin's row (`id: filemem-dsh`) in the profile's OVERRIDE layer.

## Why it must be the profile override layer (not the other two config homes)

Per the patch dialect (the dsh-base "replace whole config, no merge"
contract):
- **NOT the tarball's `cordis.patch.yml`** — it ships the install-layer row
  (`config:` = the shipped defaults); editing it is lost on reinstall.
- **NOT the host-managed `/etc/dsh-app/...` patch** — overwritten on every
  host upgrade.
- **YES `<profile>/cordis.patch.yml`** (the user layer, highest priority,
  survives host upgrades). On the phone the App boots its engine with one
  profile (usually `web` — check `ls /root/.dsh/profiles/`).

## The block (owner values; the values are the shipped defaults with the
## phone annotations)

Add to the phone's `<profile>/cordis.patch.yml`:

```yaml
# filemem-dsh: phone-side tuning. The row shadows the install-layer row BY
# ID; the config is replaced WHOLESALE (no merge) — every key the row
# needs is restated here. Remove the block + restart the engine = back to
# the install-layer defaults.
- id: filemem-dsh
  name: '@stennyc/filemem-dsh'   # asserts the install row's name (does NOT rename)
  config:
    # the path pair — restated VERBATIM from the install row (the shell
    # resolves the tilde/relative; dropping them would leave the row value-less):
    daemonPath: ../dist/filemem-go
    storePath: ~/.dsh/filemem
    # ── the deterministic data plane (fully active on the phone) ──
    k: 3                         # the auto-injection recall cap (0 = unbounded)
    enablePreStep: true         # the pre-step waterline injection + consolidation
    enableRecall: true          # the per-turn auto-recall lane master switch
    workspaceRefMax: 3          # the cross-workspace reference-lane cap (0 = pointers only)
    retrieveFilterDefault: false# the explicit retrieve face's opt-in workspace baseline
    waterLevelThreshold: 3      # the consolidation backlog early-tick threshold
    supersedeMinOverlap: 0.5    # the supersede coarse-filter Jaccard floor (0 = the 0.5 Go floor)
    supersedeMaxConfirms: 5     # the supersede-confirm per-pass N-cap
    # ── the LLM-upgrade faces: budget caps; on the phone these GATE the
    # host-LLM legs — when the profile does NOT resolve ctx.llm the legs
    # floor to their deterministic coded behavior (route d back-fill
    # still lets the App's own model author + write the summary) ──
    consolidationIntervalMin: 30
    consolidationMaxPerTick: 10
    probeBudgetPerSession: 3
    mergeBudgetPerTick: 4
    contradictionBudgetPerTick: 4
    # ── the central shared-pool face: needs the owner's PostgreSQL;
    # absent on the phone the legs fail-soft EMPTY (harmless; the keys
    # are restated so a future central-pool opt-in does not silently
    # revert to defaults) ──
    smConfirmedOnlyDefault: true
    smTopKDefault: 50
    smAgentIdDefault: ""
```

### Value notes (the owner's phone tuning surface)

- The block ships the **shipped defaults** as the phone baseline. The
  knobs the owner typically tunes on a phone: `k` (injection density),
  `workspaceRefMax` (cross-project reference noise),
  `consolidationIntervalMin` (housekeeping cadence — the phone's battery
  favors a looser interval, e.g. 60).
- The ①A/②c/③ lesson-lane behavior (the per-turn mistake lane, the
  pitfall markers) needs NO phone knob — it rides the same `k`/
  `enableRecall` admission.

## Verification (on the phone, after adding the block + restarting the engine)

1. The plugin row: `plugin_manager list_plugins` (or the App's Plugins
   page) — the `filemem-dsh` row's `config` shows the restated keys with
   the phone values.
2. Behavior legs (all in the App's agent, or the terminal page):
   - the pre-step face still injects (the auto-recall lane on a session
     with stored memories);
   - `filemem_retrieve` answers; `filemem_write` lands;
   - the consolidation log (`consolidation_log.jsonl` under the store
     root) shows ticks at the new interval;
   - WITHOUT a central PostgreSQL: the `filemem_sm_*` faces answer
     fail-soft empty (the normal floor, NOT an error);
   - WITHOUT a resolvable `ctx.llm`: the L1 handoff floor response
     carries the `model_directive` (route d) — the App's model can
     back-fill the summary via `filemem_llm_result` (`op:
     "handoff_summary"`).

## The all-or-nothing activation gate (verify FIRST, before relying on the LLM faces)

The rc1host build declares the FULL inject face (`llm` included, since
0.1.1). The host's static `inject` list is the activation gate: if the
phone's rc.1 profile does NOT resolve `llm`, the WHOLE plugin stays
inactive. If that happens: fall back to the 0.1.0 rc1host tarball
(tools-only inject, still on the releases branch) until the profile
gains the `dsh-llm` service (the rc.1 generation ships `dsh-llm` +
`dsh-token-meter` as standard services — the 2026-11-27 correction;
the missing case is a profile COMPOSITION gap, not a generation gap).

## Reversibility

Remove the block + kill the engine process (the App's supervisor
relaunches it — or close/reopen the App) = back to the install-layer
row's values (the shipped defaults). The data plane (the 14-face tool
surface) keeps running either way.

## If the manual block is too fiddly on the phone

The self-contained brief `docs/phone-settings-brief.md` (shipped in the
package) is copy-pasteable to the phone-side agent — it carries every
decision in §3's owner values and the on-device discovery steps
(§1/§2), so the phone agent executes it without external context.
