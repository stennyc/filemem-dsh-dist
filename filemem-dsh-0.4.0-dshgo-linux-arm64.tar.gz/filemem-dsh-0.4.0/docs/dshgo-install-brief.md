# filemem-dsh dshgo 件 · 手机侧安装 brief（自包含）

> 给：dsh-go App（1.4.1+）终端里的 DSH agent。目标：把 `@stennyc/filemem-dsh`
> 的 **dshgo 原生件**（dsh-go 插件协议 v1）装进本机 PRoot 引擎并验收。
> 你不需外部上下文——本 brief 自包含。与旧 rc1host 件的区别：原生面
> （面板/状态条/工具卡/点按动作）走 App 桥接；数据面与 store 完全相同
> （`~/.dsh/filemem`），换装不丢记忆。

## 0. 前提

- 本机是 **dsh-go 1.4.1+ 的 Android 本机引擎**（PRoot 内 `dsh web`）。
  老世代（只有网页半侧、无「原生界面」页签的 App）不适用本 brief——
  那种机器继续用 rc1host 件。
- 已取得 tarball `filemem-dsh-<ver>-dshgo-linux-arm64.tar.gz`（取法同
  phone-settings-brief §0 的 node one-liner 范式；本机没有 curl）。
- 若已装旧 rc1host 件（`dsh plugin` 列表里同名行）：**先卸再装**
  （同名包不可并存）。

## 1. 安装

```sh
# 1. 解压到抗「重置引擎」的保留目录
mkdir -p /root/.dsh/dsh-go/plugins
rm -rf /root/.dsh/dsh-go/plugins/filemem-dsh   # 只清插件目录，不碰 store
node -e 'const {execSync}=require("child_process");execSync("tar -xzf <tarball 路径> -C /root/.dsh/dsh-go/plugins && mv /root/.dsh/dsh-go/plugins/filemem-dsh-<ver> /root/.dsh/dsh-go/plugins/filemem-dsh")'

# 2. 链接安装（装即生效，manifest 按 mtime 自动重读）
dsh plugin --profile web add /root/.dsh/dsh-go/plugins/filemem-dsh

# 3. 验安装
dsh plugin --profile web list | grep filemem
```

- 目录要**留着**（装的是指向该目录的链接；删了插件起不来）。
- 改 `package.json` 的 `dshGo` 字段 = 自动重读；改 `dist-js/` = 在 App
  「引擎」页重启一次。

## 2. 验收（App 内）

原生面（本机引擎 + 装了桥接才有）：
- 聊天页输入框上方状态条：`N 条 · M 待决`（pool strip；点按开「记忆总览」面板）；
- 对话详情「插件」页签：记忆总览 / 未决草稿 两面板；
- 全部功能（features）：记忆总览；插件详情页：设置回显（只读）；
- 输入框上方胶囊：存记忆（把输入框文字存草稿）/ 召回（输入框文字查池 top-3 插入）；
- 回复长按菜单：存为记忆 / 记为教训；
- 每轮尾注：`记忆 N · 待决 M`；
- 工具调用结果：filemem_* 工具卡（原生视图，随对话记录走）。

数据面（与旧件相同）：
- agent 里调 `filemem_retrieve` / `filemem_write` 有答/落地；
- `~/.dsh/filemem/consolidation_log.jsonl` 按间隔出 tick；
- 无中央 PG 时 `filemem_sm_*` 回 fail-soft 空（正常地板，非报错）。

配置：所有旋钮仍走 profile 覆盖层 `cordis.patch.yml`（phone-settings-brief
§2 的块直接照抄可用——config 键集与 dshgo 件完全一致）；「设置回显」面板
只读，改动入口 = 官方设置页 / 覆盖层块。

## 3. 可逆 + 排障

- 卸载：`dsh plugin --profile web remove @stennyc/filemem-dsh`（store 保留）。
- 原生面某项缺失：App 插件详情「原生界面 · N 项有误」逐条看；
  视图组件 App 不认识 = 灰色占位，其余照画（不算错）。
- 连续违规 5 次 → 本次运行降级网页版：重启引擎或重新启用即恢复。
- 数据面与 UI 无关：原生面全挂时 14 工具面 + 注入道照常跑（降级链设计）。
